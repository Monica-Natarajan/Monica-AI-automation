package Looping;

import java.util.Scanner;

public class primenumber {

	public static void main(String[] args) {
		Scanner ne=new Scanner(System.in);
		System.out.println("Enter any number ");
		int n=ne.nextInt();
		int i=11;
		boolean isprime=true;
		if(n<=1);
		boolean isPrime =false;
		
		if (isPrime) 
		{
            System.out.println(n + " is a Prime Number.");
        } else 
        {
            System.out.println(n + " is NOT a Prime Number.");
        }

		ne.close();
    }

	
	
		}



