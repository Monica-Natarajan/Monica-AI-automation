package Looping;

public class Tables4 {
	
	void table()
	{
	for (int T=1;T<=10;T++)
	{
		int tables=4;
		System.out.println(T+"X"+tables+"="+T*4);
	}	
	}
	public static void main(String[] args) 
	{
		Tables4 obj=new Tables4();
				obj.table();

	}

}
