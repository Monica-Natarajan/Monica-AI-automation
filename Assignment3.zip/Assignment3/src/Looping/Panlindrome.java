package Looping;

public class Panlindrome {

	public static void main(String[] args) {
		
		
		int number =232;
		int app=number;
		int rev=0;
		
		while(number!=0);
		int  d=number%10;
		rev= rev*10 + d;
		number=number/10;
        System.out.println(rev);
		
		if(app==rev)
		{
			System.out.println("The number is plaindrome");
		}
		else
		{
			System.out.println("The number is not a palindrome");
		}
	}

}
