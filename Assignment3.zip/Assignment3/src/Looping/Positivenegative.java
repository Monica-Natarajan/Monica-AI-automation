package Looping;

import java.util.Scanner;

public class Positivenegative {

	public static void main(String[] args)
	{
		Scanner scanner = new Scanner(System.in);
	    System.out.print("Enter a Number: ");
	    int Number = scanner.nextInt();     
if (Number>0)
   {
    System.out.println(Number + " is positive");
   }
 else if (Number<0)
    {
        System.out.println(Number + " is positive");
    }
 else 
 {
	 System.out.println(Number + " is zero");
 }
    scanner.close(); 
    
  }

}
