package Looping;

import java.util.Scanner;

public class Factorial {

	public static void main(String[] args) {
		
		Scanner Factorial = new Scanner(System.in);
	    System.out.print("Factorial Number is: ");
	    int Fac = Factorial.nextInt();
	    
	    int i=5;
	    double fact=1;
	    for(int n=0;i>=5;i++);
	    fact=fact*i;
	    i++;
	    {
	    	System.out.println(i);
	    	
	    }
	}

}
