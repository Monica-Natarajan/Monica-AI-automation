package Looping;

import java.util.Scanner;

public class Printingnumber {

	public static void main(String[] args) {
		Scanner print = new Scanner(System.in);
	     System.out.print("Enter a year: ");
	     
	     int Number = print.nextInt();
	     for(int i=1;i<=5;i++)
			{
				System.out.print(i);
				
			}
	}

}
