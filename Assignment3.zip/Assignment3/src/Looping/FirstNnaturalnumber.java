package Looping;
import java.util.Scanner;
public class FirstNnaturalnumber {
             
	Scanner natural = new Scanner(System.in);
	System.out.print("Enter N value: ");
    
    int N = natural.nextInt();
    int totalSum = 0;
    int counter = 1;
    {
    while (counter <=N) 
    {
        totalSum += counter;
        counter++; 
    }
        System.out.println("The sum of the first " + N + " natural numbers is: " + totalSum);
        natural.close();
	}
    }



