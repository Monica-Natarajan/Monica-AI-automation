package Looping;
import java.util.Scanner;
public class Reverse 
{
  public static void main(String[] args) 
	{
		Scanner reverse = new Scanner(System.in);
	    System.out.print("Enter Number: ");
	    int number = reverse.nextInt();
	     
	     int N=1234;
	     int reversed = 0;
	     while (number != 0) {
	            int digit = number % 10;    
	            reversed = reversed * 10 + digit;
	            number = number / 10;
	            System.out.println("Reversed Number: " + reversed);
	     }
	 }
	}


