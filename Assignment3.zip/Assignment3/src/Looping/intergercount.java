package Looping;

public class intergercount {

	public static void main(String[] args) {
		
       int number=98756;
       int count=0;
       int originalNumber = number;
       while(number!=0);
       int number1 = number / 10;
       count++;  
       System.out.println("The number of digits in " + originalNumber + " is: " + count);
	}

}
