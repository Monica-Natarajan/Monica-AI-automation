package Inheritance;

public class Vehicle {
	void fueltype() {
		System.out.println("Runs on fuel");
	}
}

class Electriccar extends Vehicle {
	void Vehicle() {
		System.out.println("Runs on electricity");
	}

	public static void main(String[] args) {

		Vehicle obj = new Vehicle();
		obj.fueltype();

		Electriccar obj1 = new Electriccar();
		obj1.Vehicle();
	}
}
