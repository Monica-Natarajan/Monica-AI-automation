package Inheritance;
public class Course 
{
void courseinfo()
        {
			System.out.println("Welcoming student");
		}	
}
class Science extends Course
{
void batch1() 
	{
		System.out.println("Welcoming Science Batch");
	}			
}

 class Commers extends Course
{
void batch2()
	{
		System.out.println("Welcoming commers Batch");
	}
}

 class Arts extends Course 
{
void batch3()
	{
		System.out.println("Welcoming Arts Batch");
	}

public static void main(String[] args) {

	Science obj=new Science();
	obj.courseinfo();
	obj.batch1();
	
		
	Commers obj2=new Commers();
	obj2.batch2();
	
	
	Arts obj3=new Arts();
	obj3.batch3();
	
}
}
