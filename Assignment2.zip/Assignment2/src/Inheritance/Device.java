package Inheritance;

public class Device
{
   
	void start()
	{
		System.out.println("Model 1");
	}
	
}
 class mobile extends Device
 {
    void calling()
    {
    	System.out.println("Model 2");
    } 
 }
 class smartphone extends mobile{
	 void internet()
	 {
	  System.out.println("model 3"); 
     }

public static void main(String[] args) {
		
	
	smartphone obj=new smartphone();
	obj.start();
	obj.calling();
	obj.internet();
}

}
