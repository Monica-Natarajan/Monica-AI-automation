package Encapsulation_GetterSetter;

public class Account {
	private String accountHolderName="Monica";
	private int balance;
	
public String getAccountHolderName() 
	{
		return accountHolderName;
	}
public void setAccountHolderName(String accountHolderName) 
{
		this.accountHolderName = accountHolderName;
}
public int getBalance() {

		return balance;
}
public void setBalance(int balance) 
{
	if(balance<0)
	{
		System.out.println("warning- negative values not accepted");
	}
	else
	
	{
		this.balance = balance;
	}
}
public static void main(String[] args)
{
		Account Obj=new Account();		
        Obj.setBalance(0);
        System.out.println(Obj.getAccountHolderName());
        System.out.println(Obj.getBalance());
	}

}
