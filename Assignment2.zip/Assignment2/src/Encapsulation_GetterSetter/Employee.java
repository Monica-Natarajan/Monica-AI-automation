package Encapsulation_GetterSetter;
public class Employee 
   {
	private int id;
	private String empName;
    private double salary;
    
    public int getId() 
	{
		return id;
	}
	public void setId(int id)
	{
		this.id = id;
	}
	public String getEmpName() 
	{
		return empName;
	}
	public void setEmpName(String empName)
	{
		this.empName = empName;
	}
	public Double getSalary() 
	{
		return salary;
	}
	public void setSalary(Double salary) 
	{
		this.salary = salary;
	}
   public void displayDetails() {
		System.out.println("Employee ID: " + id);
        System.out.println("Employee Name: " + empName);
        System.out.println("Employee Salary: " + salary);
	}
   public static void main(String[] args) 
	{
		Employee obj=new Employee();
		obj.setId(101);
		obj.setEmpName("Monica");
		obj.setSalary(50000.0);
		obj.displayDetails();
	}
	}
