package Keywords;
abstract public class AbstractEmployee
{
abstract void calculateSalary(); 
	void employeeDetails() 
     {
		 System.out.println("employee details ");
     }
class FullTimeEmployee extends AbstractEmployee
{
	void calculateSalary()
	{
		System.out.println("FT employee salary details ");
	}
}
class PartTimeEmployee extends AbstractEmployee
 {
	     void calculateSalary()
		{
			System.out.println("PT employee salary details ");
		}
 } 
public static void main(String[] args) {
	AbstractEmployee obj=new AbstractEmployee();
	obj.PartTimeEmployee();
	
}
 }
	



