package Keywords;

public class school1 {
	
	private String name= "Monica";
	 private String address = "24/1";
	private int strength= 24;
	
	school1(String name, String address)
	{
		System.out.println("Name" +name);
	}
	school1(String name, String address,int strength)
	{
		System.out.println("address is " +address);
		System.out.println("strengeth" +strength);
		
	}
	void display()
	{
		System.out.println(name);
		System.out.println(address);
		System.out.println(strength);
	}
	
	public static void main(String[] args) {
		 
		school1 obj=new school1(name,address);
				obj.display();

	}

}
