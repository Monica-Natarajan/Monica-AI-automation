package Keywords;

class  Super_Person
{
	Super_Person()
	 {
	  System.out.println("Person Created");
	 }
}
class Student extends Super_Person
{	 
	Student()
	
	{
	super();
	System.out.println("Student Created");
	}
	
	
	public static void main(String[] args)
	{
		Super_Person obj=new Super_Person();
	
	}

}
