package Keywords;
public class school {
private String name="PMS";
	
	 school() 
	{
		System.out.println("school name "+ name);
	}
	 
    public void schoolname()
	{
		System.out.println("This School is based out of Kolkata");	
	}
	

public static void main(String[] args) {
		
		school obj=new school();
		obj.schoolname();
		
	}
			
	}
	
		
	
