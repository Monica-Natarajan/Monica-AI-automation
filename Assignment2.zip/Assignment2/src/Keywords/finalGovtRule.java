package Keywords;

public class finalGovtRule 
{
	
	final int WorkingHours = 8;
     private String Variable ="mondays";
	
     void display()
	{
		String WorkingDays = "MonDay, Friday";
		
	}
	public static void main(String[] args)
	{
		finalGovtRule obj=new finalGovtRule();
		obj.display();
	

	}

}
