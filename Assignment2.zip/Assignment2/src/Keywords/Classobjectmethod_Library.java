package Keywords;

public class Classobjectmethod_Library
{
	private String libraryName="APJ library";	
	
		void message()
		{
		{
		System.out.println ("Welcome to the Library!"+libraryName);
		}	
	}
   public void showLocation(){
	{
	  System.out.println ("This library is located in Mumbai");
	}
   }
	public static void main(String[] args) {
		
		Classobjectmethod_Library obj=new Classobjectmethod_Library();
		obj.message();
		
		Classobjectmethod_Library obj1=new Classobjectmethod_Library();
		obj1.showLocation();
		
	}

}
