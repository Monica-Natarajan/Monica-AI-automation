package Keywords;

public class Finalbank
{
	final String IFCS="1123";
     
     final void showIFSC()
    {
    	System.out.println(IFCS);
    	
    }
    
 class HDFCBank extends showIFSC
 {
	 {
	    	System.out.println("hdfc IFCS IS 987");
	}
 }	 
	public static void main(String[] args) 
	{
		Finalbank obj=new Finalbank();
		obj.showIFSC();
	 
	}
 }
