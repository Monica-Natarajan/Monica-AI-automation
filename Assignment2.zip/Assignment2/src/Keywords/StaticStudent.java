package Keywords;

public class StaticStudent
{
	static String collegename= "CSC OOTY COLLAGE";
	private String name="Monica";
	private int rollno = 24;
	
	 void display()
	{
		System.out.println("collegename name is "+collegename);
		System.out.println("name is " + name);
		System.out.println("roll no is " +rollno);
	}
	
	public static void main(String[] args) {
		
		StaticStudent obj=new StaticStudent();
		obj.display();
		

	}

}
