package Keywords;

public class shape {
	
	private int length;
	
   void square()
   {
	   System.out.println("area of rectangle");
   }
	void rectangle()
	{
		
		System.out.println("area of rectangle");
	}
	
	void circle()
	{
		System.out.println("area of circle");
	}

	public static void main(String[] args) {
		
		shape obj=new shape();
		obj.square();
		obj.rectangle();
		obj.circle();
	}

}
