package Keywords;

public class University {
	
	static String country = ("India");
	String universityName = ("Bharadhiyar");

	public static void main(String[] args) {
		
		University obj=new University();
		System.out.println(obj.country);
		System.out.println(obj.universityName);
		
		
		
	}

}
