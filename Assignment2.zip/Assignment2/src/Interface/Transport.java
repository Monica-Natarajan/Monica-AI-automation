package Interface;

public interface Transport 
{
	 void booking();
}
abstract class Bus implements Transport
{
	public void booking()
	{
		System.out.println("Bus Ticket booking");
	}
}
 class Flight implements Transport
{	
	public void booking()
	{
		System.out.println("Flight Ticket booking");
	}
class main{
public static void main(String[]args) {

Transport ref = new Flight();
	ref.booking();
}

}}