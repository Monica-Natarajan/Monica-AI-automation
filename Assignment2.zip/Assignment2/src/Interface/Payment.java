package Interface;

public interface Payment 
{
	abstract void makePayment();
}	
 class UPI implements Payment
{
		public void makePayment()
		{
	     System.out.println("UPI payment successfull");
	    }
}
 class CreditCard implements Payment
     {
	 public void makePayment()
		{
	     System.out.println("Credit card payment successfull");
	    }
public static void main(String[] args) {
	Payment pay1=new UPI();
	pay1.makePayment();
	
	Payment pay2=new CreditCard();
	pay2.makePayment();
	
}
}

	



