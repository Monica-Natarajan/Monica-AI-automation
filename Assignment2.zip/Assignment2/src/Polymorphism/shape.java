package Polymorphism;

class shape {
	void area() 
	{
		System.out.println("area calculating ");
	}
}	
class Rectangle extends shape{
void area() 
{
	System.out.println("area of Rectangle=length*width");
}
class Circle extends shape
{
void area() 
{
      System.out.println("area of circle= π * r * r ");
}
}
public static void main(String[] args) {
		
		
		Rectangle obj=new Rectangle();
		obj.area();
		
}}
