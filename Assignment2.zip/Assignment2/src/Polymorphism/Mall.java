package Polymorphism;

public class Mall {
	
	 void Malls()
	 {
		System.out.println("Welcome to the Mall"); 
	}
class a1 extends Mall
{
	
	{
	 this.Malls();
	}	 

public static void main(String[] args) 
{

	a1 obj=new a1();
	obj.Malls();
}
}}
