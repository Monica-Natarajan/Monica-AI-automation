package Polymorphism;

public class Camera {
	
	void capture() 
	{
		System.out.println("capturing image ");
	}
}
class DSLCamera	extends Camera 
{
	void capture() 
	{
	System.out.println("capturing with dslr");
	}
public static void main(String[] args)
{
	
	{
		Camera obj=new DSLCamera();
		obj.capture();
	}
	}
}
