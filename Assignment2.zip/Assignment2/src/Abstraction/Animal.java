package Abstraction;

public abstract class Animal 
 {
    abstract void sound();
 }
 class Dog extends Animal
{
	  void sound()
	 {
		 System.out.println("Dod sounds Bow Bow");
	}		 
}
 class cat extends Animal
{
	  void sound()
     {
    	 System.out.println("cat sounds meow meow");
	 }
public static void main(String[] args)

	{
	Animal mydog= new Dog();
	mydog.sound();
	Animal mycat= new cat();
	mycat.sound();
	 }
}
