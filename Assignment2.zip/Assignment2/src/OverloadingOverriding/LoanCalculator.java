package OverloadingOverriding;

public class LoanCalculator 
{
	
	void calculateLoan(int amount) 
	{
	System.out.println(amount);
	}
	void calculateLoan(int amount, double interestRate)
	{
	System.out.println("Loan amount" + amount);
	System.out.println("intrest loan amount" +interestRate);
	}

	public static void main(String[] args) 
	{
		LoanCalculator obj=new LoanCalculator();
		obj.calculateLoan( 20000);
		obj.calculateLoan(30000,88.9);
	}
}
