package OverloadingOverriding;

public class Hospital 
{
	void emergencyService()
	{
	System.out.println("EmergencyService is avaiable");
	}
}
 class CityHospital extends Hospital
 {
	 { 
     super.emergencyService();
	 System.out.println("In City Hospital EmergencyService is avaiable");
	 }

 public static void main(String[] args) 
	{
	 CityHospital obj=new CityHospital();
		 obj.emergencyService();
		 
	}}
		 
	
