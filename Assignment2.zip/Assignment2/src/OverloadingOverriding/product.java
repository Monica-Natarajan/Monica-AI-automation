package OverloadingOverriding;

public class product {
	
	public int productid;
	public String productname;
	public double price;
	
	void displayProduct()
	{
		System .out.println("Product Created");
	}
	
	void displayProduct(int id,String name,double price) 
	{
		System .out.println("product id is " + id);
		System .out.println("product name is " + name);
		System .out.println("product price is " + price);
	}
	public static void main(String[]args)
	
	{
		product obj=new product();
		obj.displayProduct(100 , " soap " ,80.0);
		
	}

}
	