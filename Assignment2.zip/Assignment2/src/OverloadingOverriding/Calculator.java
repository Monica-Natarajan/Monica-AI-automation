package OverloadingOverriding;

public class Calculator 
{

	void add(int a,int b) 
	{
		System.out.println ("int value =" + (a+b));
	}
	
	void add(double a,double b) 
	{
		System.out.println ("double value =" +(a+b));
	}
	 public static void main(String[] args) 
	{
		Calculator obj=new Calculator();
		 obj.add(10,20);
		 obj.add(10.3, 12.5);
	}

}
